<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}
?>
<p class="qodef-m-posts-not-found qodef-grid-item"><?php esc_html_e( 'No posts were found for provided query parameters.', 'qi-addons-for-elementor' ); ?></p>
