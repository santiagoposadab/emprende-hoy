<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

require_once QI_ADDONS_FOR_ELEMENTOR_ADMIN_PATH . '/inc/media/class-qiaddonsforelementor-framework-image-sizes.php';
