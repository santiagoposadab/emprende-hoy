<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

esc_html_e( 'Copyright © 2024 Qode Interactive, All rights reserved', 'qi-addons-for-elementor' );
