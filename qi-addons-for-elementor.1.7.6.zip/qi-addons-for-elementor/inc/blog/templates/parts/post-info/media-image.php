<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}
?>
<div class="qodef-e-media">
	<?php qi_addons_for_elementor_template_part( 'blog', 'templates/parts/post-info/image', '', $params ); ?>
</div>
