<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

include_once QI_ADDONS_FOR_ELEMENTOR_SHORTCODES_PATH . '/dual-image-with-content/class-qiaddonsforelementor-dual-image-with-content-shortcode.php';
