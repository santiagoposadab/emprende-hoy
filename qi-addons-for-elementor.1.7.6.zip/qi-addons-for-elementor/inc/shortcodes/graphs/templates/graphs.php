<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}
?>
<div <?php qi_addons_for_elementor_framework_class_attribute( $holder_classes ); ?> <?php qi_addons_for_elementor_framework_inline_attrs( $data_attrs, true ); ?>>
	<div class="qodef-m-inner">
		<div class="qodef-m-canvas-holder">
			<div class="qodef-m-canvas">
				<canvas></canvas>
			</div>
		</div>
	</div>
</div>
