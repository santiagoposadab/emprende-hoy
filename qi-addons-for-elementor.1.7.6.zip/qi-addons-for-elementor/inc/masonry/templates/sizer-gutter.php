<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

if ( 'masonry' === $params ) {
	?>
	<div class="qodef-qi-grid-masonry-sizer"></div>
<?php } ?>
