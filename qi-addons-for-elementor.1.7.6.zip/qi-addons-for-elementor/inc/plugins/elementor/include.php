<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

if ( qi_addons_for_elementor_framework_is_installed( 'elementor' ) ) {
	include_once QI_ADDONS_FOR_ELEMENTOR_PLUGINS_PATH . '/elementor/helper.php';
	include_once QI_ADDONS_FOR_ELEMENTOR_PLUGINS_PATH . '/elementor/class-qiaddonsforelementor-elementor-section-handler.php';
}
